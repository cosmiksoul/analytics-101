# report.py
# Задаём исходные данные перед расчётом выручки
orders = [1200, 850, 2300, 640, 1750]  # суммы заказов, ₽
discount = 0.1

total = sum(orders) * (1 - discount)
avg = total / len(orders)

print(f"Выручка: {total:.0f} ₽, средний чек: {avg:.0f} ₽")
